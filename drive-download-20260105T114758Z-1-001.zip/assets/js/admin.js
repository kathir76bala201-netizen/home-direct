// Lightweight admin helper stubs
// These functions are no-op fallbacks that log and show a notification
// They are only defined if not already present to avoid overriding page-specific logic.

(function(){
    const notify = (msg, type='info') => {
        if (window.RealEstatePro && typeof window.RealEstatePro.showNotification === 'function') {
            window.RealEstatePro.showNotification(msg, type);
        } else {
            console.log(`[notify:${type}] ${msg}`);
        }
    };

    const define = (name, fn) => {
        if (typeof window[name] === 'undefined') window[name] = fn;
    };

    define('approveAllPending', function(){ notify('Approve all pending (stub)', 'info'); });
    define('approveProperty', function(id){ notify('Approved property '+id, 'success'); console.log('approveProperty', id); });
    define('rejectProperty', function(id){ notify('Rejected property '+id, 'warning'); console.log('rejectProperty', id); });
    define('viewProperty', function(id){ notify('Viewing property '+id, 'info'); console.log('viewProperty', id); });
    define('editProperty', function(id){ notify('Edit property '+id, 'info'); console.log('editProperty', id); });
    define('toggleFeatured', function(id, featured=null){ notify('Toggled featured '+id, 'info'); console.log('toggleFeatured', id, featured); });
    define('applyBulkAction', function(){ notify('Applied bulk action (stub)', 'info'); });
    define('clearFilters', function(){ notify('Cleared filters', 'info'); });
    define('deleteProperty', function(id){ notify('Deleted property '+id, 'warning'); console.log('deleteProperty', id); });

    // User management
    define('exportData', function(format){ notify('Export '+format+' (stub)', 'info'); });
    define('addNewUser', function(){
        if (typeof openModal === 'function') openModal('add');
        else notify('Add new user (stub)', 'info');
    });
    define('viewUserDetails', function(id){
        if (typeof openModal === 'function') openModal('view', id);
        else notify('View user '+id, 'info');
    });
    define('editUser', function(id){
        if (typeof openModal === 'function') openModal('edit', id);
        else notify('Edit user '+id, 'info');
    });
    define('toggleUserStatus', function(id, btn){
        if (btn && btn.textContent) btn.textContent = btn.textContent.trim() === 'Block' ? 'Unblock' : 'Block';
        notify('Toggled user status '+id, 'info');
    });

    // Generic helpers
    define('toggleSelectAll', function(){
        // Try to toggle checkbox groups if present
        const master = document.querySelector('#selectAll');
        if (!master) return;
        const checkboxes = document.querySelectorAll('.item-checkbox');
        checkboxes.forEach(cb => cb.checked = master.checked);
        notify('Toggled select all', 'info');
    });
})();
