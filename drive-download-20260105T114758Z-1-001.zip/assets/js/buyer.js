// Shared buyer utilities
(function(){
    'use strict';


    window.viewProperty = function(id){
        // Redirect to property-details page with id in query string
        if(id){
            window.location.href = 'property-details.html?id=' + encodeURIComponent(id);
        } else {
            window.location.href = 'property-details.html';
        }
    };

    window.viewPropertyDetails = function(id){
        window.viewProperty(id);
    };


    window.toggleSaveProperty = function(btn, id){
        // btn: DOM element (button)
        if(!btn) return;
        if(btn.classList.contains('saved')){
            btn.classList.remove('saved');
            btn.innerHTML = '<i class="far fa-heart"></i> Save';
            if(window.RealEstatePro && window.RealEstatePro.showNotification) RealEstatePro.showNotification('Removed from saved properties','info');
        } else {
            btn.classList.add('saved');
            btn.innerHTML = '<i class="fas fa-check"></i> Saved';
            if(window.RealEstatePro && window.RealEstatePro.showNotification) RealEstatePro.showNotification('Added to saved properties','success');
        }
    };


    window.removeSavedProperty = function(id){
        // Remove property card dynamically (no redirect)
        const card = document.querySelector(`.property-card[data-id="${id}"]`);
        if(card){
            card.style.opacity = '0.5';
            card.style.pointerEvents = 'none';
            setTimeout(() => {
                card.remove();
                try{ if(typeof updateSavedStats === 'function') updateSavedStats(); }catch(e){}
                const grid = document.getElementById('savedPropertiesGrid');
                const empty = document.getElementById('emptySavedState');
                if(empty) empty.style.display = grid && grid.children.length === 0 ? 'block' : 'none';
                if(window.RealEstatePro && window.RealEstatePro.showNotification) RealEstatePro.showNotification('Property removed from saved.','info');
            }, 300);
        }
    };

    // helper: toggle select all checkboxes (if present)
    window.toggleSelectAllSaved = function(){
        const checkboxes = document.querySelectorAll('.select-property');
        const selectAll = document.getElementById('selectAllSaved');
        if(!selectAll) return;
        checkboxes.forEach(c => { c.checked = selectAll.checked; });
    };

})();
