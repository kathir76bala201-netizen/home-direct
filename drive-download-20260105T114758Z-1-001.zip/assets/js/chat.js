// Chat functionality

class Chat {
    constructor() {
        this.currentConversation = null;
        this.messages = [];
        this.initializeChat();
        this.loadConversations();
        this.setupEventListeners();
    }
    
    initializeChat() {
        // Set up message container
        this.messageContainer = document.querySelector('.chat-messages');
        this.chatInput = document.querySelector('.chat-input');
        this.sendButton = document.querySelector('.send-btn');
        
        // Auto-resize textarea
        if (this.chatInput) {
            this.chatInput.addEventListener('input', this.autoResizeTextarea.bind(this));
        }
    }
    
    autoResizeTextarea() {
        this.chatInput.style.height = 'auto';
        this.chatInput.style.height = Math.min(this.chatInput.scrollHeight, 120) + 'px';
    }
    
    loadConversations() {
        // In a real app, this would fetch from API
        const conversations = [
            {
                id: 1,
                name: 'John Smith',
                avatar: 'JS',
                lastMessage: 'I\'m interested in the property...',
                time: '10:30 AM',
                unread: 2,
                online: true
            },
            {
                id: 2,
                name: 'Sarah Johnson',
                avatar: 'SJ',
                lastMessage: 'When can we schedule a viewing?',
                time: 'Yesterday',
                unread: 0,
                online: false
            },
            {
                id: 3,
                name: 'Michael Brown',
                avatar: 'MB',
                lastMessage: 'Is the price negotiable?',
                time: '2 days ago',
                unread: 1,
                online: true
            }
        ];
        
        this.renderConversations(conversations);
        
        // Load first conversation by default
        if (conversations.length > 0) {
            this.selectConversation(conversations[0]);
        }
    }
    
    renderConversations(conversations) {
        const container = document.querySelector('.conversations-body');
        if (!container) return;
        
        container.innerHTML = conversations.map(conv => `
            <div class="conversation-item ${this.currentConversation?.id === conv.id ? 'active' : ''}" 
                 data-conversation-id="${conv.id}">
                <div class="conversation-avatar" style="background: ${this.getAvatarColor(conv.name)}">
                    ${conv.avatar}
                </div>
                <div class="conversation-info">
                    <div class="conversation-name">${conv.name}</div>
                    <div class="conversation-preview">${conv.lastMessage}</div>
                </div>
                <div class="conversation-meta">
                    <div class="conversation-time">${conv.time}</div>
                    ${conv.unread > 0 ? `<div class="unread-badge">${conv.unread}</div>` : ''}
                </div>
            </div>
        `).join('');
        
        // Add click listeners
        container.querySelectorAll('.conversation-item').forEach(item => {
            item.addEventListener('click', () => {
                const convId = item.dataset.conversationId;
                const conversation = conversations.find(c => c.id == convId);
                if (conversation) {
                    this.selectConversation(conversation);
                }
            });
        });
    }
    
    getAvatarColor(name) {
        const colors = [
            '#2563eb', '#10b981', '#f59e0b', '#8b5cf6',
            '#ef4444', '#ec4899', '#06b6d4', '#84cc16'
        ];
        const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
        return colors[hash % colors.length];
    }
    
    async selectConversation(conversation) {
        this.currentConversation = conversation;
        
        // Update UI
        document.querySelectorAll('.conversation-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-conversation-id="${conversation.id}"]`)?.classList.add('active');
        
        // Update chat header
        const chatHeader = document.querySelector('.chat-header');
        if (chatHeader) {
            chatHeader.innerHTML = `
                <div class="chat-user-info">
                    <div class="conversation-avatar" style="background: ${this.getAvatarColor(conversation.name)}">
                        ${conversation.avatar}
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 1.125rem;">${conversation.name}</h3>
                        <div class="chat-status">
                            <span class="status-dot" style="background: ${conversation.online ? '#10b981' : '#6b7280'}"></span>
                            ${conversation.online ? 'Online' : 'Offline'}
                        </div>
                    </div>
                </div>
                <div class="chat-actions">
                    <button class="btn btn-outline btn-sm" onclick="chat.callUser()">
                        <i class="fas fa-phone"></i>
                    </button>
                </div>
            `;
        }
        
        // Load messages for this conversation
        await this.loadMessages(conversation.id);
    }
    
    async loadMessages(conversationId) {
        // In a real app, fetch from API
        const mockMessages = [
            {
                id: 1,
                sender: 'other',
                message: 'Hi, I\'m interested in your property listing.',
                time: '10:15 AM',
                read: true
            },
            {
                id: 2,
                sender: 'me',
                message: 'Hello! Thank you for your interest. What would you like to know?',
                time: '10:20 AM',
                read: true
            },
            {
                id: 3,
                sender: 'other',
                message: 'Is the price negotiable? And when can I schedule a viewing?',
                time: '10:25 AM',
                read: true
            },
            {
                id: 4,
                sender: 'me',
                message: 'Yes, the price is negotiable. I\'m available for viewings this weekend.',
                time: '10:30 AM',
                read: true
            }
        ];
        
        this.messages = mockMessages;
        this.renderMessages();
        
        // Mark as read
        this.markConversationAsRead(conversationId);
    }
    
    renderMessages() {
        if (!this.messageContainer) return;
        
        this.messageContainer.innerHTML = this.messages.map(msg => `
            <div class="message message-${msg.sender === 'me' ? 'sent' : 'received'}">
                <div class="message-text">${msg.message}</div>
                <div class="message-time">${msg.time}</div>
            </div>
        `).join('');
        
        // Scroll to bottom
        this.scrollToBottom();
    }
    
    scrollToBottom() {
        if (this.messageContainer) {
            this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
        }
    }
    
    markConversationAsRead(conversationId) {
        // Update UI
        const convItem = document.querySelector(`[data-conversation-id="${conversationId}"]`);
        if (convItem) {
            const unreadBadge = convItem.querySelector('.unread-badge');
            if (unreadBadge) {
                unreadBadge.remove();
            }
        }
        
        // Update unread count
        this.updateUnreadCount();
    }
    
    updateUnreadCount() {
        const unreadBadges = document.querySelectorAll('.unread-badge');
        const totalUnread = Array.from(unreadBadges).reduce((sum, badge) => {
            return sum + parseInt(badge.textContent);
        }, 0);
        
        // Update header badge if exists
        const headerBadge = document.querySelector('.header-unread-badge');
        if (headerBadge) {
            if (totalUnread > 0) {
                headerBadge.textContent = totalUnread;
                headerBadge.style.display = 'flex';
            } else {
                headerBadge.style.display = 'none';
            }
        }
    }
    
    setupEventListeners() {
        // Send message on button click
        if (this.sendButton) {
            this.sendButton.addEventListener('click', this.sendMessage.bind(this));
        }
        
        // Send message on Enter (with Shift for new line)
        if (this.chatInput) {
            this.chatInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }
        
        // Search conversations
        const searchInput = document.querySelector('.conversations-search input');
        if (searchInput) {
            searchInput.addEventListener('input', this.searchConversations.bind(this));
        }
    }
    
    async sendMessage() {
        if (!this.chatInput || !this.chatInput.value.trim() || !this.currentConversation) return;
        
        const message = this.chatInput.value.trim();
        
        // Add to messages
        const newMessage = {
            id: this.messages.length + 1,
            sender: 'me',
            message: message,
            time: this.getCurrentTime(),
            read: false
        };
        
        this.messages.push(newMessage);
        this.renderMessages();
        
        // Clear input
        this.chatInput.value = '';
        this.autoResizeTextarea();
        
        // Focus back on input
        this.chatInput.focus();
        
        // In a real app, send to server
        try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 500));
            
            // Simulate response
            setTimeout(() => {
                const response = {
                    id: this.messages.length + 1,
                    sender: 'other',
                    message: 'Thanks! I\'ll get back to you soon.',
                    time: this.getCurrentTime(),
                    read: false
                };
                
                this.messages.push(response);
                this.renderMessages();
            }, 1000);
            
        } catch (error) {
            console.error('Failed to send message:', error);
            window.RealEstatePro.showNotification('Failed to send message', 'error');
        }
    }
    
    getCurrentTime() {
        const now = new Date();
        return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    
    searchConversations(e) {
        const searchTerm = e.target.value.toLowerCase();
        const convItems = document.querySelectorAll('.conversation-item');
        
        convItems.forEach(item => {
            const name = item.querySelector('.conversation-name').textContent.toLowerCase();
            const preview = item.querySelector('.conversation-preview').textContent.toLowerCase();
            
            if (name.includes(searchTerm) || preview.includes(searchTerm)) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    callUser() {
        if (!this.currentConversation) return;
        
        window.RealEstatePro.showNotification(`Calling ${this.currentConversation.name}...`, 'info');
        
        // In a real app, initiate a call
        // This is just a demo
    }
    
    // Initialize video/audio call
    initCall(type = 'audio') {
        if (!this.currentConversation) return;
        
        window.RealEstatePro.showNotification(`Starting ${type} call with ${this.currentConversation.name}`, 'info');
        
        // In a real app, use WebRTC for calls
    }
}

// Initialize chat when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.chat = new Chat();
});