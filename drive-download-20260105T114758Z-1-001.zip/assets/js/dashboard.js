// Dashboard specific functionality

class Dashboard {
    constructor() {
        this.initializeCharts();
        this.initializeDataTables();
        this.initializeNotifications();
        this.initializePropertyActions();
    }
    
    initializeCharts() {
        // Initialize charts if Chart.js is available
        if (typeof Chart !== 'undefined') {
            this.createStatsCharts();
        }
    }
    
    createStatsCharts() {
        // User growth chart (for admin)
        const userGrowthCtx = document.getElementById('userGrowthChart');
        if (userGrowthCtx) {
            new Chart(userGrowthCtx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                    datasets: [{
                        label: 'New Users',
                        data: [65, 78, 90, 120, 150, 180],
                        borderColor: '#2563eb',
                        backgroundColor: 'rgba(37, 99, 235, 0.1)',
                        tension: 0.3
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        }
        
        // Property listings chart
        const listingsCtx = document.getElementById('listingsChart');
        if (listingsCtx) {
            new Chart(listingsCtx, {
                type: 'bar',
                data: {
                    labels: ['Apartments', 'Houses', 'Villas', 'Commercial'],
                    datasets: [{
                        label: 'Listings',
                        data: [120, 85, 45, 30],
                        backgroundColor: [
                            '#2563eb',
                            '#10b981',
                            '#f59e0b',
                            '#8b5cf6'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        }
    }
    
    initializeDataTables() {
        // Initialize simple data tables
        const tables = document.querySelectorAll('.data-table');
        
        tables.forEach(table => {
            this.enhanceTable(table);
        });
    }
    
    enhanceTable(table) {
        // Add sorting functionality
        const headers = table.querySelectorAll('th[data-sort]');
        
        headers.forEach(header => {
            header.style.cursor = 'pointer';
            header.addEventListener('click', () => {
                this.sortTable(table, header);
            });
        });
        
        // Add row selection
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
            row.addEventListener('click', (e) => {
                if (!e.target.closest('.table-actions')) {
                    row.classList.toggle('selected');
                }
            });
        });
    }
    
    sortTable(table, header) {
        const columnIndex = Array.from(header.parentNode.children).indexOf(header);
        const isAscending = !header.classList.contains('asc');
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.querySelectorAll('tr'));
        
        // Clear previous sorting
        table.querySelectorAll('th').forEach(th => {
            th.classList.remove('asc', 'desc');
        });
        
        // Sort rows
        rows.sort((a, b) => {
            const aValue = a.children[columnIndex].textContent.trim();
            const bValue = b.children[columnIndex].textContent.trim();
            
            // Try to parse as number
            const aNum = parseFloat(aValue.replace(/[^0-9.-]+/g, ''));
            const bNum = parseFloat(bValue.replace(/[^0-9.-]+/g, ''));
            
            if (!isNaN(aNum) && !isNaN(bNum)) {
                return isAscending ? aNum - bNum : bNum - aNum;
            }
            
            // Otherwise sort as string
            return isAscending 
                ? aValue.localeCompare(bValue)
                : bValue.localeCompare(aValue);
        });
        
        // Reorder rows
        rows.forEach(row => tbody.appendChild(row));
        
        // Update header class
        header.classList.add(isAscending ? 'asc' : 'desc');
    }
    
    initializeNotifications() {
        // Mark notifications as read
        const notificationItems = document.querySelectorAll('.notification-item');
        
        notificationItems.forEach(item => {
            item.addEventListener('click', () => {
                if (!item.classList.contains('read')) {
                    item.classList.add('read');
                    
                    // Update unread count
                    const unreadCount = document.querySelector('.unread-count');
                    if (unreadCount) {
                        const count = parseInt(unreadCount.textContent) - 1;
                        unreadCount.textContent = count > 0 ? count : '';
                        if (count <= 0) {
                            unreadCount.style.display = 'none';
                        }
                    }
                }
            });
        });
        
        // Mark all as read
        const markAllReadBtn = document.querySelector('.mark-all-read');
        if (markAllReadBtn) {
            markAllReadBtn.addEventListener('click', () => {
                notificationItems.forEach(item => {
                    item.classList.add('read');
                });
                
                const unreadCount = document.querySelector('.unread-count');
                if (unreadCount) {
                    unreadCount.style.display = 'none';
                }
                
                window.RealEstatePro.showNotification('All notifications marked as read', 'success');
            });
        }
    }
    
    initializePropertyActions() {
        // Quick actions for property cards
        const propertyCards = document.querySelectorAll('.property-card');
        
        propertyCards.forEach(card => {
            const saveBtn = card.querySelector('.save-property');
            const viewBtn = card.querySelector('.view-property');
            
            if (saveBtn) {
                saveBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const propertyId = saveBtn.dataset.propertyId;
                    this.toggleSaveProperty(propertyId, saveBtn);
                });
            }
            
            if (viewBtn) {
                viewBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const propertyId = viewBtn.dataset.propertyId;
                    this.viewPropertyDetails(propertyId);
                });
            }
            
            // Whole card click
            card.addEventListener('click', (e) => {
                if (!e.target.closest('.property-actions')) {
                    const propertyId = card.dataset.propertyId;
                    this.viewPropertyDetails(propertyId);
                }
            });
        });
    }
    
    toggleSaveProperty(propertyId, button) {
        const isSaved = button.classList.contains('saved');
        
        // In a real app, this would be an API call
        if (isSaved) {
            button.classList.remove('saved');
            button.innerHTML = '<i class="far fa-heart"></i>';
            button.title = 'Save property';
            window.RealEstatePro.showNotification('Property removed from saved', 'info');
        } else {
            button.classList.add('saved');
            button.innerHTML = '<i class="fas fa-heart" style="color: #ef4444;"></i>';
            button.title = 'Remove from saved';
            window.RealEstatePro.showNotification('Property saved to favorites', 'success');
        }
    }
    
    viewPropertyDetails(propertyId) {
        // Navigate to property details page
        window.location.href = `property-details.html?id=${propertyId}`;
    }
    
    // Export dashboard data
    exportData(format = 'csv') {
        const table = document.querySelector('.data-table');
        if (!table) return;
        
        let data = [];
        const headers = Array.from(table.querySelectorAll('th')).map(th => th.textContent);
        
        table.querySelectorAll('tbody tr').forEach(row => {
            const rowData = {};
            Array.from(row.querySelectorAll('td')).forEach((td, index) => {
                rowData[headers[index]] = td.textContent;
            });
            data.push(rowData);
        });
        
        if (format === 'csv') {
            this.downloadCSV(data, headers);
        } else if (format === 'json') {
            this.downloadJSON(data);
        }
    }
    
    downloadCSV(data, headers) {
        const csvContent = [
            headers.join(','),
            ...data.map(row => headers.map(header => `"${row[header]}"`).join(','))
        ].join('\n');
        
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'dashboard-export.csv';
        a.click();
    }
    
    downloadJSON(data) {
        const jsonContent = JSON.stringify(data, null, 2);
        const blob = new Blob([jsonContent], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'dashboard-export.json';
        a.click();
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.dashboard = new Dashboard();
});