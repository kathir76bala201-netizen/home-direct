// Main JavaScript for RealEstate Pro

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    initializeTooltips();
    
    // Initialize form validation
    initializeFormValidation();
    
    // Initialize property interactions
    initializePropertyInteractions();
    
    // Initialize mobile menu if needed
    initializeMobileMenu();
});

// Tooltip functionality
function initializeTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', function(e) {
            const tooltipText = this.getAttribute('data-tooltip');
            if (!tooltipText) return;
            
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = tooltipText;
            tooltip.style.position = 'absolute';
            tooltip.style.background = '#1f2937';
            tooltip.style.color = 'white';
            tooltip.style.padding = '8px 12px';
            tooltip.style.borderRadius = '4px';
            tooltip.style.fontSize = '12px';
            tooltip.style.zIndex = '10000';
            tooltip.style.maxWidth = '200px';
            tooltip.style.whiteSpace = 'nowrap';
            
            document.body.appendChild(tooltip);
            
            const rect = this.getBoundingClientRect();
            tooltip.style.top = (rect.top - tooltip.offsetHeight - 10) + 'px';
            tooltip.style.left = (rect.left + rect.width / 2 - tooltip.offsetWidth / 2) + 'px';
            
            this._tooltip = tooltip;
        });
        
        element.addEventListener('mouseleave', function() {
            if (this._tooltip) {
                this._tooltip.remove();
                this._tooltip = null;
            }
        });
    });
}

// Form validation
function initializeFormValidation() {
    const forms = document.querySelectorAll('form[data-validate]');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
            }
        });
    });
}

function validateForm(form) {
    let isValid = true;
    const requiredFields = form.querySelectorAll('[required]');
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            showFieldError(field, 'This field is required');
            isValid = false;
        } else {
            clearFieldError(field);
            
            // Email validation
            if (field.type === 'email' && !isValidEmail(field.value)) {
                showFieldError(field, 'Please enter a valid email address');
                isValid = false;
            }
            
            // Password confirmation
            if (field.hasAttribute('data-confirm')) {
                const confirmField = form.querySelector(`[name="${field.getAttribute('data-confirm')}"]`);
                if (field.value !== confirmField.value) {
                    showFieldError(field, 'Passwords do not match');
                    isValid = false;
                }
            }
        }
    });
    
    return isValid;
}

function showFieldError(field, message) {
    clearFieldError(field);
    
    field.style.borderColor = '#ef4444';
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.style.color = '#ef4444';
    errorDiv.style.fontSize = '0.875rem';
    errorDiv.style.marginTop = '0.25rem';
    errorDiv.textContent = message;
    
    field.parentNode.appendChild(errorDiv);
}

function clearFieldError(field) {
    field.style.borderColor = '';
    
    const existingError = field.parentNode.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Property interactions
function initializePropertyInteractions() {
    // Save property functionality
    const saveButtons = document.querySelectorAll('.save-property');
    
    saveButtons.forEach(button => {
        button.addEventListener('click', function() {
            const propertyId = this.getAttribute('data-property-id');
            const isSaved = this.classList.contains('saved');
            
            if (isSaved) {
                unsaveProperty(propertyId, this);
            } else {
                saveProperty(propertyId, this);
            }
        });
    });
    
    // Property image gallery navigation
    const propertyGalleries = document.querySelectorAll('.property-gallery');
    
    propertyGalleries.forEach(gallery => {
        const mainImage = gallery.querySelector('.gallery-main');
        const thumbnails = gallery.querySelectorAll('.gallery-thumbnail');
        
        thumbnails.forEach(thumbnail => {
            thumbnail.addEventListener('click', function() {
                const newSrc = this.getAttribute('data-full');
                mainImage.src = newSrc;
                
                // Update active thumbnail
                thumbnails.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
            });
        });
    });
}

function saveProperty(propertyId, button) {
    // In a real application, this would be an API call
    button.classList.add('saved');
    button.innerHTML = '<i class="fas fa-heart" style="color: #ef4444;"></i>';
    
    showNotification('Property saved to favorites', 'success');
}

function unsaveProperty(propertyId, button) {
    // In a real application, this would be an API call
    button.classList.remove('saved');
    button.innerHTML = '<i class="far fa-heart"></i>';
    
    showNotification('Property removed from favorites', 'info');
}

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.padding = '16px 24px';
    notification.style.borderRadius = '8px';
    notification.style.color = 'white';
    notification.style.zIndex = '10000';
    notification.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
    notification.style.display = 'flex';
    notification.style.alignItems = 'center';
    notification.style.gap = '12px';
    
    // Set background color based on type
    switch(type) {
        case 'success':
            notification.style.backgroundColor = '#10b981';
            notification.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
            break;
        case 'error':
            notification.style.backgroundColor = '#ef4444';
            notification.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
            break;
        case 'warning':
            notification.style.backgroundColor = '#f59e0b';
            notification.innerHTML = `<i class="fas fa-exclamation-triangle"></i> ${message}`;
            break;
        default:
            notification.style.backgroundColor = '#2563eb';
            notification.innerHTML = `<i class="fas fa-info-circle"></i> ${message}`;
    }
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.3s ease';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
}

// Mobile menu initialization
function initializeMobileMenu() {
    const mobileMenuButton = document.querySelector('.mobile-menu-button');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuButton && navLinks) {
        mobileMenuButton.addEventListener('click', function() {
            navLinks.classList.toggle('show');
        });
    }
}

// Price formatting utility
function formatPrice(price) {
    if (price >= 1000000) {
        return '$' + (price / 1000000).toFixed(1) + 'M';
    } else if (price >= 1000) {
        return '$' + (price / 1000).toFixed(0) + 'K';
    } else {
        return '$' + price;
    }
}

// Export utilities for use in other files
window.RealEstatePro = {
    formatPrice,
    showNotification,
    validateForm
};