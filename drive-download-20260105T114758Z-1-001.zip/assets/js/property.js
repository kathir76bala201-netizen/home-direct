// Property page functionality

class PropertyPage {
    constructor() {
        this.propertyId = this.getPropertyIdFromURL();
        this.initializeGallery();
        this.initializeContactForm();
        this.initializeSaveButton();
        this.initializeMap();
        this.loadPropertyDetails();
    }
    
    getPropertyIdFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('id') || '1';
    }
    
    initializeGallery() {
        const mainImage = document.querySelector('.gallery-main img');
        const thumbnails = document.querySelectorAll('.gallery-thumbnail');
        
        if (!mainImage || !thumbnails.length) return;
        
        thumbnails.forEach(thumbnail => {
            thumbnail.addEventListener('click', () => {
                const newSrc = thumbnail.querySelector('img').src.replace('-thumb', '');
                mainImage.src = newSrc;
                
                // Update active thumbnail
                thumbnails.forEach(t => t.classList.remove('active'));
                thumbnail.classList.add('active');
            });
        });
        
        // Initialize zoom on main image
        if (mainImage) {
            mainImage.addEventListener('click', () => {
                this.openLightbox(mainImage.src);
            });
        }
    }
    
    openLightbox(imageSrc) {
        const lightbox = document.createElement('div');
        lightbox.className = 'lightbox';
        lightbox.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            cursor: zoom-out;
        `;
        
        const img = document.createElement('img');
        img.src = imageSrc;
        img.style.cssText = `
            max-width: 90%;
            max-height: 90%;
            object-fit: contain;
        `;
        
        const closeBtn = document.createElement('button');
        closeBtn.innerHTML = '&times;';
        closeBtn.style.cssText = `
            position: absolute;
            top: 20px;
            right: 20px;
            background: none;
            border: none;
            color: white;
            font-size: 3rem;
            cursor: pointer;
            z-index: 10001;
        `;
        
        lightbox.appendChild(img);
        lightbox.appendChild(closeBtn);
        document.body.appendChild(lightbox);
        
        // Close lightbox
        closeBtn.addEventListener('click', () => lightbox.remove());
        lightbox.addEventListener('click', (e) => {
            if (e.target === lightbox) lightbox.remove();
        });
        
        // Close with ESC key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') lightbox.remove();
        });
    }
    
    initializeContactForm() {
        const contactForm = document.getElementById('contactForm');
        if (!contactForm) return;
        
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            if (this.validateContactForm()) {
                this.submitContactForm();
            }
        });
    }
    
    validateContactForm() {
        const form = document.getElementById('contactForm');
        let isValid = true;
        
        const requiredFields = form.querySelectorAll('[required]');
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                this.showFieldError(field, 'This field is required');
                isValid = false;
            } else {
                this.clearFieldError(field);
                
                if (field.type === 'email') {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(field.value)) {
                        this.showFieldError(field, 'Please enter a valid email');
                        isValid = false;
                    }
                }
            }
        });
        
        return isValid;
    }
    
    showFieldError(field, message) {
        this.clearFieldError(field);
        
        const errorDiv = document.createElement('div');
        errorDiv.className = 'field-error';
        errorDiv.style.cssText = `
            color: #ef4444;
            font-size: 0.875rem;
            margin-top: 0.25rem;
        `;
        errorDiv.textContent = message;
        
        field.parentNode.appendChild(errorDiv);
        field.style.borderColor = '#ef4444';
    }
    
    clearFieldError(field) {
        const existingError = field.parentNode.querySelector('.field-error');
        if (existingError) {
            existingError.remove();
        }
        field.style.borderColor = '';
    }
    
    async submitContactForm() {
        const form = document.getElementById('contactForm');
        const formData = new FormData(form);
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        // Show loading state
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
        submitBtn.disabled = true;
        
        try {
            // In a real app, this would be an API call
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            window.RealEstatePro.showNotification('Your message has been sent successfully!', 'success');
            form.reset();
            
            // Update enquiry counter if exists
            const enquiryCount = document.querySelector('.enquiry-count');
            if (enquiryCount) {
                const count = parseInt(enquiryCount.textContent) + 1;
                enquiryCount.textContent = count;
            }
            
        } catch (error) {
            window.RealEstatePro.showNotification('Failed to send message. Please try again.', 'error');
        } finally {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    }
    
    initializeSaveButton() {
        const saveBtn = document.querySelector('.save-property-btn');
        if (!saveBtn) return;
        
        // Check if property is already saved
        const savedProperties = JSON.parse(localStorage.getItem('savedProperties') || '[]');
        const isSaved = savedProperties.includes(this.propertyId);
        
        if (isSaved) {
            saveBtn.innerHTML = '<i class="fas fa-heart"></i> Saved';
            saveBtn.classList.add('saved');
        }
        
        saveBtn.addEventListener('click', () => {
            this.toggleSaveProperty(saveBtn);
        });
    }
    
    toggleSaveProperty(button) {
        const savedProperties = JSON.parse(localStorage.getItem('savedProperties') || '[]');
        const isSaved = savedProperties.includes(this.propertyId);
        
        if (isSaved) {
            // Remove from saved
            const index = savedProperties.indexOf(this.propertyId);
            savedProperties.splice(index, 1);
            button.innerHTML = '<i class="far fa-heart"></i> Save Property';
            button.classList.remove('saved');
            window.RealEstatePro.showNotification('Property removed from saved', 'info');
        } else {
            // Add to saved
            savedProperties.push(this.propertyId);
            button.innerHTML = '<i class="fas fa-heart"></i> Saved';
            button.classList.add('saved');
            window.RealEstatePro.showNotification('Property saved to favorites', 'success');
        }
        
        localStorage.setItem('savedProperties', JSON.stringify(savedProperties));
        
        // Update saved count in header if exists
        const savedCount = document.querySelector('.saved-count');
        if (savedCount) {
            savedCount.textContent = savedProperties.length;
        }
    }
    
    initializeMap() {
        const mapElement = document.getElementById('propertyMap');
        if (!mapElement) return;
        
        // Initialize a simple map (in a real app, use Google Maps or Leaflet)
        mapElement.innerHTML = `
            <div style="width: 100%; height: 100%; background: #f3f4f6; display: flex; align-items: center; justify-content: center; color: #6b7280;">
                <div style="text-align: center;">
                    <i class="fas fa-map-marker-alt" style="font-size: 3rem; margin-bottom: 1rem;"></i>
                    <p>Map view would show here</p>
                    <p class="text-sm">(Google Maps integration)</p>
                </div>
            </div>
        `;
    }
    
    async loadPropertyDetails() {
        // In a real app, this would fetch from an API
        // For demo purposes, we'll simulate loading
        
        const loadingElements = document.querySelectorAll('.skeleton-loading');
        loadingElements.forEach(el => {
            el.classList.add('loading');
        });
        
        try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Remove loading states
            loadingElements.forEach(el => {
                el.classList.remove('loading', 'skeleton-loading');
            });
            
        } catch (error) {
            console.error('Failed to load property details:', error);
            window.RealEstatePro.showNotification('Failed to load property details', 'error');
        }
    }
    
    // Share property functionality
    shareProperty() {
        const shareData = {
            title: document.title,
            text: 'Check out this property on RealEstate Pro',
            url: window.location.href
        };
        
        if (navigator.share) {
            navigator.share(shareData)
                .then(() => window.RealEstatePro.showNotification('Property shared successfully', 'success'))
                .catch(err => console.log('Error sharing:', err));
        } else {
            // Fallback: copy to clipboard
            navigator.clipboard.writeText(window.location.href)
                .then(() => window.RealEstatePro.showNotification('Link copied to clipboard', 'success'))
                .catch(err => console.log('Error copying:', err));
        }
    }

    // Scroll to / focus contact form when 'Contact Owner' button is clicked
    contactOwner() {
        const form = document.getElementById('contactForm');
        if (form) {
            form.scrollIntoView({ behavior: 'smooth', block: 'center' });
            const textarea = form.querySelector('textarea');
            if (textarea) textarea.focus();
            return true;
        }

        window.RealEstatePro.showNotification('Contact form not available', 'warning');
        return false;
    }
}

// Initialize property page
document.addEventListener('DOMContentLoaded', () => {
    window.propertyPage = new PropertyPage();
    
    // Add share button listener if exists
    const shareBtn = document.querySelector('.share-property-btn');
    if (shareBtn) {
        shareBtn.addEventListener('click', () => {
            window.propertyPage.shareProperty();
        });
    }
});